### To get started, start the server

`pnpm run dev`
